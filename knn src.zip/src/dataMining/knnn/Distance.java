package dataMining.knnn;

import java.util.ArrayList;

public class Distance {
	
	
	
	
	
	public Distance()
	{
	
	}
	
	public double calculateDistance( ArrayList<Integer>testTemp, ArrayList<Integer>trainTemp)
	{
	   
		double sum=0.0;
	    for(int i=0;i<testTemp.size();i++)
	    {
	    	sum+=Math.pow(trainTemp.get(i)-testTemp.get(i),2);
	    	
	    }
	    
	    return Math.sqrt(sum);
	
	}
}
