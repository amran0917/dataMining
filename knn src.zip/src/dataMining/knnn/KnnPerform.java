package dataMining.knnn;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

public class KnnPerform {

	
	public KnnPerform() {
		
	}
	
	public int getResult(ArrayList<Result>rs)
	{
		
		int k=3;
		int count_1=0,count_2=0;
	
		MaxCount[] arr=new MaxCount[k];
		for(int i=0;i<k;i++){
			
			Result res1=rs.get(i);
			arr[i]=new MaxCount(0,res1.className);
			for(int j=0;j<k;j++) {
				
				Result res2=rs.get(j);
				
				if(res1.getClassName()==res2.getClassName()) {
					
					arr[i].count++;
				}
				
			}
			
			
			
			
		} 
		
		Arrays.sort(arr);
		
		for(int i=0;i<arr.length;i++) {
			
		//	System.out.println("ClassName "+arr[i].className);
		}
		
		return arr[0].className;
		
		
	}

}
