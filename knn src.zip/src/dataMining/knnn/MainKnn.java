package dataMining.knnn;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

public class MainKnn {

	public static void main(String []args) throws IOException
	{
		
		File file = new File("F:\\eclipse\\MyKnn\\src\\dataMining\\knnn\\caesarian.txt");
		BufferedReader br =new BufferedReader(new FileReader(file));
		String sr;	
		int countLine=0; 
		
	
		
       ArrayList <RootData> data = new ArrayList<RootData>();
       ArrayList<ArrayList<Integer>> arr = new ArrayList<ArrayList<Integer>>();
     
    
		
		while((sr=br.readLine())!=null)
		{
			
			String[] s =sr.split(",");
		
			
			ArrayList<Integer> ar2 = new ArrayList<Integer>();
			
			int len =s.length;

			   for(int j=0;j<len;j++)
			   {
				
				  ar2.add(Integer.parseInt(s[j]));
			   }
			   arr.add(ar2);
			  
			  // System.out.println(ar2);
			 /*  RootData rd = new RootData();
			   rd.setArrayList(ar2);
			   data.add(rd);*/
				
			  
			   countLine++;
		} 
		
	/*	for(int x=0;x<countLine;x++) {
			
			for(int y=0;y<4;y++)
			{
				//System.out.println(arr.get(x).get(y));
				data.add(arr.get(x).get(y), null);
				
			}
						
		} */
		
	
		ValidationCheck cr = new ValidationCheck(arr);
		cr.makeTrainingDataSet();
			
		
		
	}
	
}
