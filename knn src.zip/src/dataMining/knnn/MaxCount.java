package dataMining.knnn;

public class MaxCount implements Comparable<MaxCount>{
	
	int count;
	int className;
	
	public MaxCount(int count,int className) {
		
		this.count=count;
		this.className=className;
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}

	public int getClassName() {
		return className;
	}

	public void setClassName(int className) {
		this.className = className;
	}
	
	@Override
	public int compareTo(MaxCount arg) {
		// TODO Auto-generated method stub
		
		MaxCount res=(MaxCount) arg;
		
		if(this.count>res.count) return -1;
		else return 1;
	
	}
	

}
