package dataMining.knnn;

public class Result implements Comparable<Result>{

	int className;
	double distance;
	public Result(int className, double distance) {
		
		this.className = className;
		this.distance = distance;
	}
	
	
	public int getClassName() {
		return className;
	}
	public void setClassName(int className) {
		this.className = className;
	}
	public double getDistance() {
		return distance;
	}
	public void setDistance(double distance) {
		this.distance = distance;
	}
	
	@Override
	public int compareTo(Result arg) {
		// TODO Auto-generated method stub
		
		Result res=(Result) arg;
		
		if(this.distance<res.distance) return -1;
		else return 1;
	
	}


	
}
