package dataMining.knnn;

import java.util.ArrayList;

public class RootData {
	
	 
	//public int cls;
	public ArrayList<Integer>arr = new ArrayList<>();
	public boolean test;
	
	
	
	
	public RootData()
	{
		//this.cls=cls;
		this.test= false;
	//	arr=new int[arr.length];
	//	this.arr =arr;
	}
	
	public void setArrayList(ArrayList<Integer>arr)
	{
		this.arr=arr;
	}
	
	public ArrayList<Integer> getArrayList()
	{
		return arr;
	}

}
