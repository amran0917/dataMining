package dataMining.knnn;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ValidationCheck {
	

	 ArrayList<ArrayList<Integer>> data ;
	int match=0;
	int tp=0,tn=0,fp=0,fn=0;
	double precision,recall,f1_score;
	
	
	public ValidationCheck( ArrayList<ArrayList<Integer>> data)
	{
		this.data = data;
		
	}
	
	public void makeTrainingDataSet()
	{
		int totalLine=data.size();
		int testData = totalLine/10;
		int trainData= totalLine-testData;
		int m;
		
		
		for(int i=0;i<10;i++)
		{
			Collections.shuffle(data);
		
			 ArrayList<ArrayList<Integer>> test = new ArrayList<ArrayList<Integer>>();
			 ArrayList<ArrayList<Integer>> train = new ArrayList<ArrayList<Integer>>();
			 ArrayList<Result> res=new ArrayList<Result>();
			 
			for(int k=0;k<testData;k++)
			{
				test.add(data.get(k));
				
			}
		
			 m=testData;
			
			
			while(m!=totalLine)
			{
				train.add(data.get(m));
				m++;
			} 
			
			for(int j=0;j<testData;j++) {
				ArrayList<Integer> testTemp=test.get(j);
				
				for(int k=0;k<trainData;k++) {
					ArrayList<Integer> trainTemp=train.get(k);
					
					Distance dist=new Distance();
					int className=trainTemp.get(trainTemp.size()-1);
					double distance=dist.calculateDistance(testTemp, trainTemp);
					
					Result rs=new Result(className,distance);
					
					res.add(rs);
					Collections.sort(res);
					
					
				}
				
				for(int k=0;k<res.size();k++) {
					
					Result r=res.get(k);
					
				//	System.out.println("ClassName "+r.className+"Distance "+r.distance);
				}
					
				KnnPerform knn = new KnnPerform();
				int className=knn.getResult(res);
				
				int testclassName=testTemp.get(testTemp.size()-1);
				
				if(className==testclassName)
				{ 
					match++;
					
				}
				  
			/*	if(className==1 && testclassName==1)
				{
					tp++;
				}
				
				else if(className==1 && testclassName==2)
				{
					tn++;
				}
				else if(className==2 && testclassName==1)
				{
					fp++;
				}
				else if(className==2 && testclassName==2)
				{
					fn++;
				} */
				
				
				
				
			}
			
		
	
		}
		accuracyMeasure(match,totalLine);
	//	PerformanceMeasure(tp,fp,tn,fn);
		
	} 
	
	void accuracyMeasure(int match,int totalLine)
	{
	
			System.out.println("Accuracy: "+((double)match/totalLine)*100+" %");
	 }
	
	void PerformanceMeasure(int tp,int fp,int tn,int fn)
	{
		 precision = (double)tp/(tp+fp)*100;
		 recall= (double)tp/(tp+fn)*100;
		  f1_score=(double)(2*(recall * precision)) / (recall + precision);
		   
		   System.out.println("Precision: "+precision+"% \n"+" Recall: "+recall+"%\n"+" f1_score "+f1_score+"%");
	}
	
}
